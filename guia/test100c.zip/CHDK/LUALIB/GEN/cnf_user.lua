--[[
GENERATED user_menu_conf_info TABLE
--]]
return {
 _config_id=3000,
 _first_entry=3001,
 user_menu_vars=3001,
 user_menu_as_root=3002,
 user_menu_enable=3003,
 _last_entry=3003
}
